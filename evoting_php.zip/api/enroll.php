<?php
require "db.php";

$voterId = $_POST["voterId"] ?? null;
$name    = $_POST["name"] ?? "";

if (!$voterId || !isset($_FILES["fingerprint"])) {
  die(json_encode(["error"=>"missing fields"]));
}

$file = $_FILES["fingerprint"]["tmp_name"];
$hash = hash_file("sha256", $file);

$stmt = $conn->prepare("INSERT INTO users (voter_id, name, fingerprint_hash) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE name=?, fingerprint_hash=?");
$stmt->bind_param("sssss", $voterId, $name, $hash, $name, $hash);
$stmt->execute();

echo json_encode(["ok"=>true, "voterId"=>$voterId, "fingerprintHash"=>$hash]);
?>