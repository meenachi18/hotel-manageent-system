<?php
// Simple blockchain simulation using a JSON file
$chainFile = __DIR__ . "/../chain.json";

function getBlockchain() {
  global $chainFile;
  if (!file_exists($chainFile)) {
    $genesis = [["index"=>0, "timestamp"=>time(), "data"=>"genesis", "prevHash"=>"0", "hash"=>hash("sha256","genesis")]];
    file_put_contents($chainFile, json_encode($genesis, JSON_PRETTY_PRINT));
  }
  return json_decode(file_get_contents($chainFile), true);
}

function addBlock($data) {
  global $chainFile;
  $chain = getBlockchain();
  $prev = end($chain);
  $index = count($chain);
  $block = [
    "index"=>$index,
    "timestamp"=>time(),
    "data"=>$data,
    "prevHash"=>$prev["hash"]
  ];
  $block["hash"] = hash("sha256", $index.$block["timestamp"].json_encode($data).$block["prevHash"]);
  $chain[] = $block;
  file_put_contents($chainFile, json_encode($chain, JSON_PRETTY_PRINT));
  return $block;
}
?>