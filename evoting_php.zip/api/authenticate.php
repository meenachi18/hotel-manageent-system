<?php
require "db.php";

$voterId    = $_POST["voterId"] ?? null;
$electionId = $_POST["electionId"] ?? null;

if (!$voterId || !$electionId || !isset($_FILES["fingerprint"])) {
  die(json_encode(["error"=>"missing fields"]));
}

$file = $_FILES["fingerprint"]["tmp_name"];
$hash = hash_file("sha256", $file);

$res = $conn->query("SELECT * FROM users WHERE voter_id='$voterId'");
if ($res->num_rows == 0) {
  die(json_encode(["error"=>"voter not found"]));
}
$user = $res->fetch_assoc();

if ($user["fingerprint_hash"] !== $hash) {
  die(json_encode(["error"=>"fingerprint mismatch"]));
}
if ($user["has_voted"]) {
  die(json_encode(["error"=>"already voted"]));
}

echo json_encode(["ok"=>true, "voterId"=>$voterId]);
?>