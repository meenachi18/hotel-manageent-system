<?php
require "db.php";
require "blockchain.php";

$data = json_decode(file_get_contents("php://input"), true);
$voterId = $data["voterId"] ?? null;
$electionId = $data["electionId"] ?? null;
$option = $data["option"] ?? null;

if (!$voterId || !$electionId || !$option) {
  die(json_encode(["error"=>"missing fields"]));
}

$res = $conn->query("SELECT * FROM users WHERE voter_id='$voterId'");
if ($res->num_rows == 0) die(json_encode(["error"=>"voter not found"]));
$user = $res->fetch_assoc();
if ($user["has_voted"]) die(json_encode(["error"=>"already voted"]));

$conn->query("INSERT INTO votes (election_id, voter_id, option_chosen) VALUES ('$electionId','$voterId','$option')");
$conn->query("UPDATE users SET has_voted=1 WHERE voter_id='$voterId'");

$block = addBlock(["voterId"=>$voterId,"electionId"=>$electionId,"option"=>$option]);

echo json_encode(["ok"=>true,"block"=>$block]);
?>