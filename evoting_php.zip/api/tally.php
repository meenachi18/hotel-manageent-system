<?php
require "db.php";

$electionId = $_GET["electionId"] ?? null;
if (!$electionId) die(json_encode(["error"=>"missing electionId"]));

$res = $conn->query("SELECT option_chosen, COUNT(*) as cnt FROM votes WHERE election_id='$electionId' GROUP BY option_chosen");

$output = [];
while ($row = $res->fetch_assoc()) {
  $output[$row["option_chosen"]] = $row["cnt"];
}

echo json_encode(["electionId"=>$electionId, "counts"=>$output]);
?>