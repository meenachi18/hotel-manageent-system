# eVoting Demo (PHP + XAMPP + MySQL)

## 📂 Project Structure
- `api/` → Backend PHP APIs
- `uploads/` → Uploaded fingerprint files
- `index.html` + `script.js` → Simple frontend

## ⚙️ Database Setup
1. Start XAMPP (Apache + MySQL).
2. In phpMyAdmin, create a database `evoting`.
3. Run this SQL:

```sql
CREATE TABLE users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  voter_id VARCHAR(50) UNIQUE,
  name VARCHAR(100),
  fingerprint_hash VARCHAR(255),
  has_voted TINYINT DEFAULT 0
);

CREATE TABLE elections (
  id INT AUTO_INCREMENT PRIMARY KEY,
  election_id VARCHAR(50) UNIQUE,
  title VARCHAR(100),
  options TEXT
);

CREATE TABLE votes (
  id INT AUTO_INCREMENT PRIMARY KEY,
  election_id VARCHAR(50),
  voter_id VARCHAR(50),
  option_chosen VARCHAR(50),
  timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

## ▶️ Running the Demo
1. Place the `evoting/` folder inside `C:/xampp/htdocs/`.
2. Start Apache and MySQL from XAMPP Control Panel.
3. Open browser at [http://localhost/evoting](http://localhost/evoting).
4. Use the UI to:
   - Enroll a voter (upload an image file as fingerprint).
   - Authenticate (upload the same file).
   - Cast a vote.
   - View tally.

⚠️ Note: Fingerprint recognition is **simulated** by hashing the uploaded file. Use the same file for both enrollment and authentication.
