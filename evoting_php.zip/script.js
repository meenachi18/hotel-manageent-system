function show(out){ document.getElementById("output").innerText = JSON.stringify(out,null,2); }

document.getElementById("enrollForm").onsubmit = async e => {
  e.preventDefault();
  let fd = new FormData(e.target);
  let res = await fetch("api/enroll.php", {method:"POST", body:fd});
  show(await res.json());
};

document.getElementById("authForm").onsubmit = async e => {
  e.preventDefault();
  let fd = new FormData(e.target);
  let res = await fetch("api/authenticate.php", {method:"POST", body:fd});
  show(await res.json());
};

async function castVote(){
  let voterId = document.getElementById("voteVoterId").value;
  let electionId = document.getElementById("voteElectionId").value;
  let option = document.getElementById("voteOption").value;
  let res = await fetch("api/vote.php", {method:"POST", body:JSON.stringify({voterId,electionId,option})});
  show(await res.json());
}

async function getTally(){
  let electionId = document.getElementById("tallyElectionId").value;
  let res = await fetch("api/tally.php?electionId="+electionId);
  show(await res.json());
}